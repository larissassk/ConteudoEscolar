<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Exercicio 3</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>
<body>
    <!-- Escreva um algoritmo que receba um valor, calcule e mostre para usuário 15% deste valor. -->
    <?php

   $Val = 25;

    // Calculando 15% do valor
    $porcentagem = $Val * 0.15;
    
   echo "15% de $Val é : ". $porcentagem;
    ?>
</body>
</html>