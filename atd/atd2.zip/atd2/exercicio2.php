<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Exercicio 2</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>
<body>
    <!-- Escreva um algoritmo que leia três números nas variáveis Val1, Val2 e Val3, calcule sua média na variável media e exiba para o usuário o resultado -->
    <?php

    $Val1 = 2;
    $Val2 = 4;
    $Val3 = 6;

    $Rmedia = ($Val1 + $Val2 + $Val3) / 3;
   
     echo"este é o resultado da media dos números $Val1, $Val2, $Val3 é : $Rmedia ";

    ?>
</body>
</html>