<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Exercicio 1</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>
<body>
    <!-- Escreva um algoritmo para somar dois números e multiplicar o resultado pelo primeiro número. -->
    <?php

    //Define os numeros
    $numero1 = 2;
    $numero2 = 3;

    // Faz as somas 
    $soma = $numero1 + $numero2;
    $resultado = $soma * $numero1;

   // Imprime o resultado
    echo "O resultado da soma do $numero1 e $numero2 multiplicado pelo $numero1 é: $resultado";
    
    ?>
</body>
</html>